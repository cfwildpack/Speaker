# 🔊 SoundWave Website

Simple speaker-themed website project for GitHub.

## Features
- Modern dark UI
- Product section
- Interactive button (JavaScript)
- Clean layout

## How to Run
Open `index.html` in your browser.

## Author
Created for GitHub project practice.
