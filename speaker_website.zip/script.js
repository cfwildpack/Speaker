function playSound() {
  alert("🔊 Imagine powerful bass here!");
}
